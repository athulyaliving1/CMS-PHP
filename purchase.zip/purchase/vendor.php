<?php
session_start();
error_reporting(1);
include('includes/config.php');
if (strlen($_SESSION['login']) == "") {
    header('location:index.php');
} else {

    if (isset($_POST['submit'])) {
        $uid = $_SESSION['id'];
        $category = $_POST['category'];
        $subcat = $_POST['subcategory'];
        $reqtype = $_POST['reqtype'];
        $state = $_POST['state'];
        $reqdetials = $_POST['reqdetails'];
        $locations = $_POST['locations'];
        $place = $_POST['place'];
        $vendor = $_POST['vendor'];


        $reqfile = $_FILES["reqfile"]["name"];

        move_uploaded_file($_FILES["reqfile"]["tmp_name"], "reqdocs/" . $_FILES["reqfile"]["name"]);


        $query = mysqli_query($con, "INSERT INTO `purchase` (`reqNumber`,`userId`,`category`,`subcategory`,`reqType`,   `state`,`reqDetails`,`place`,`vendor`) VALUES (5556,555,4,'Browser','Non-Emergency','MARKETING','test requirements',1);");


    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>CMS | User Register Requirement</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-daterangepicker/daterangepicker.css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
    <script>
        function getCat(val) {
            //alert('val');

            $.ajax({
                type: "POST",
                url: "getsubcat.php",
                data: 'catid=' + val,
                success: function (data) {
                    $("#subcategory").html(data);

                }
            });
        }
    </script>

</head>

<body>

    <section id="container">

        <section id="main-content">
            <section class="wrapper">
                <h3><i class="fa fa-angle-right"></i> Register Your Vendor Details</h3>

                <!-- BASIC FORM ELELEMNTS -->
                <div class="row mt">
                    <div class="col-lg-12">
                        <div class="form-panel">


                            <?php if ($successmsg) { ?>
                            <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert"
                                    aria-hidden="true">&times;</button>
                                <b>Well done!</b> <?php echo htmlentities($successmsg); ?>
                            </div>
                            <?php } ?>

                            <?php if ($errormsg) { ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert"
                                    aria-hidden="true">&times;</button>
                                <b>Oh snap!</b> </b> <?php echo htmlentities($errormsg); ?>
                            </div>
                            <?php } ?>

                            <form class="form-horizontal style-form" method="post" name="complaint"
                                enctype="multipart/form-data">

                                <div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Vendor Name</label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="vendor Name"
                                                name="vendorname" required="required" autofocus>
                                        </div>
                                        <label class="col-sm-2 col-sm-2 control-label">Contact number </label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="Contact number"
                                                name="cnumber" required="required" autofocus>
                                        </div>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Location</label>
                                    <div class="col-sm-4">
                                        <select name="locations" class="form-control" required="">
                                            <option value="">Select Your Location</option>
                                            <option value="Chennai">Chennai</option>
                                            <option value="Bangalore">Bangalore</option>
                                            <option value="Bangalore">Kochi</option>
                                            <option value="Bangalore">Coimbatore</option>

                                        </select>

                                    </div>
                                    <label class="col-sm-2 col-sm-2 control-label">Place</label>
                                    <div class="col-sm-4">
                                        <select name="place" class="form-control" required="">
                                            <option value="">Select Your Location</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="karnataka">karnataka</option>
                                            <option value="kerala">Kerala</option>


                                        </select>
                                    </div>
                                </div>

                                <div>
                                    <div class="form-group">

                                        <label class="col-sm-2 col-sm-2 control-label">Vendor-code </label>

                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="Vendor code"
                                                name="vendorcode" required="required" autofocus>
                                        </div>

                                        <label class="col-sm-2 col-sm-2 control-label">Mail-Id </label>

                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="Mail-Id" name="mail"
                                                required="required" autofocus>
                                        </div>

                                    </div>
                                </div>
                                <div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">GST No</label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="GST No" name="gstno"
                                                required="required" autofocus>
                                        </div>
                                        <label class="col-sm-2 col-sm-2 control-label">PAN Number</label>

                                        <div class="col-sm-4">
                                            <input type="text" class="form-control" placeholder="PAN Number" name="pan"
                                                required="required" autofocus>
                                        </div>

                                    </div>
                                </div>






                                <div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Category</label>
                                        <div class="col-sm-4">
                                            <select name="category" id="category" class="form-control"
                                                onChange="getCat(this.value);" required="">
                                                <option value="">Select Category</option>
                                                <?php $sql = mysqli_query($con, "select id,categoryName from category ");
    while ($rw = mysqli_fetch_array($sql)) {
                                                ?>
                                                <option value="<?php echo htmlentities($rw['id']); ?>"><?php echo htmlentities($rw['categoryName']); ?></option>
                                                <?php
    }
                                                ?>
                                            </select>
                                        </div>
                                        <label class="col-sm-2 col-sm-2 control-label">Sub Category </label>
                                        <div class="col-sm-4">
                                            <select name="subcategory" id="subcategory" class="form-control">
                                                <option value="">Select Subcategory</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="form-group">
                                            <label class="col-sm-2 col-sm-2 control-label">Category</label>
                                            <div class="col-sm-4">
                                                <select name="category" id="category" class="form-control"
                                                    onChange="getCat(this.value);" required="">
                                                    <option value="">Select Category</option>
                                                    <?php $sql = mysqli_query($con, "select id,categoryName from category ");
    while ($rw = mysqli_fetch_array($sql)) {
                                                    ?>
                                                    <option value="<?php echo htmlentities($rw['id']); ?>"><?php echo htmlentities($rw['categoryName']); ?></option>
                                                    <?php
    }
                                                    ?>
                                                </select>
                                            </div>
                                            <label class="col-sm-2 col-sm-2 control-label">Sub Category </label>
                                            <div class="col-sm-4">
                                                <select name="subcategory" id="subcategory" class="form-control">
                                                    <option value="">Select Subcategory</option>
                                                </select>
                                            </div>
                                        </div>






                                        <div class="form-group">
                                            <label class="col-sm-2 col-sm-2 control-label">Requirement Related Doc(if
                                                any)
                                            </label>
                                            <div class="col-sm-6">
                                                <input type="file" name="reqfile" class="form-control" value="">
                                            </div>
                                        </div>



                                        <div class="form-group">
                                            <div class="col-sm-10" style="padding-left:25% ">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>

                            </form>
                        </div>
                    </div>
                </div>



            </section>
        </section>
        <?php include("includes/footer.php"); ?>
    </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>

    <!--custom switch-->
    <script src="assets/js/bootstrap-switch.js"></script>

    <!--custom tagsinput-->
    <script src="assets/js/jquery.tagsinput.js"></script>

    <!--custom checkbox & radio-->

    <script type="text/javascript" src="assets/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-daterangepicker/date.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-daterangepicker/daterangepicker.js"></script>

    <script type="text/javascript" src="assets/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>


    <script src="assets/js/form-component.js"></script>


    <script>
        //custom select box

        $(function () {
            $('select.styled').customSelect();
        });

    </script>

</body>

</html>
<?php } ?>







<!-- 
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Requirement Type</label>
                                    <div class="col-sm-4">
                                        <select name="reqtype" class="form-control" required="">
                                            <option value="Emergency">Emergency</option>
                                            <option value="Non-Emergency">Non-Emergency</option>
                                        </select>
                                    </div>

                                    <label class="col-sm-2 col-sm-2 control-label">Department</label>
                                    <div class="col-sm-4">
                                        <select name="state" required="required" class="form-control">
                                            <option value="">Select Department</option>
                                            <?php /*  $sql = mysqli_query($con, "select stateName from state ");
                                             while ($rw = mysqli_fetch_array($sql)) {
                                             ?>
                                             <option value="<?php echo htmlentities($rw['stateName']); ?>"><?php echo htmlentities($rw['stateName']); ?></option>
                                             <?php
                                             }*/
                                            ?>

                                        </select>
                                    </div>
                                </div> -->


<!-- <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Location</label>
                                        <div class="col-sm-4">
                                            <select name="locations" class="form-control" required="">
                                                <option value="">Select Your Location</option>
                                                <option value="Chennai">Chennai</option>
                                                <option value="Bangalore">Bangalore</option>
                                                <option value="Bangalore">Kochi</option>
                                                <option value="Bangalore">Coimbatore</option>

                                            </select>

                                        </div>
                                        <label class="col-sm-2 col-sm-2 control-label">Place</label>
                                        <div class="col-sm-4">
                                            <select name="place" class="form-control" required="">
                                                <option value="">Select Your Location</option>
                                                <option value="Tamil Nadu">Tamil Nadu</option>
                                                <option value="karnataka">karnataka</option>
                                                <option value="kerala">Kerala</option>


                                            </select>
                                        </div>
                                    </div> -->



<!-- <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Vendor</label>
                                        <div class="col-sm-4">
                                            <select name="locations" class="form-control" required="">
                                                <option value="">Select Your Vendor</option>
                                                <option value="Chennai">Chennai</option>
                                                <option value="Bangalore">Bangalore</option>
                                                <option value="Bangalore">Kochi</option>
                                                <option value="Bangalore">Coimbatore</option>

                                            </select>

                                        </div>
                                    </div> -->





<!-- <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Requirement Details (max 2000
                                            words)
                                        </label>
                                        <div class="col-sm-6">
                                            <textarea name="reqdetails" required="required" cols="10" rows="10"
                                                class="form-control" maxlength="2000"></textarea>
                                        </div>
                                    </div> -->